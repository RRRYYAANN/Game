function Move() {
  window.moveBy(1, 1);
  setInterval(Move(), 100);
}
Move();
