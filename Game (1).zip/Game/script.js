function myFunction() {
  monkey = window.open(
    `${document.URL}/Mokey.html`,
    "",
    "width=500, height=300",
    
    
  );
  

  
  

}

